import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Settings, Check, Copy, ExternalLink, ShieldAlert } from "lucide-react";
import { toast } from "sonner";

interface CheckoutConfigProps {
  onLinkChange?: (newLink: string) => void;
  defaultLink?: string;
}

export default function CheckoutConfig({ onLinkChange, defaultLink = "https://lastlink.com/p/C1B37CAF5/checkout-payment/" }: CheckoutConfigProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [checkoutLink, setCheckoutLink] = useState(defaultLink);
  const [tempLink, setTempLink] = useState(defaultLink);
  const [isCopied, setIsCopied] = useState(false);

  // Carregar link salvo no localStorage ao iniciar
  useEffect(() => {
    const savedLink = localStorage.getItem("danielle_nani_checkout_link");
    // Forçar a atualização se o link antigo estiver salvo para garantir que use o link oficial fornecido
    if (savedLink && !savedLink.includes("C1B37CAF5")) {
      localStorage.setItem("danielle_nani_checkout_link", defaultLink);
      setCheckoutLink(defaultLink);
      setTempLink(defaultLink);
      if (onLinkChange) {
        onLinkChange(defaultLink);
      }
    } else if (savedLink) {
      setCheckoutLink(savedLink);
      setTempLink(savedLink);
      if (onLinkChange) {
        onLinkChange(savedLink);
      }
    } else {
      // Se não houver link salvo, salvar o padrão
      localStorage.setItem("danielle_nani_checkout_link", defaultLink);
    }
  }, [defaultLink, onLinkChange]);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validação básica de URL
    if (!tempLink.startsWith("http://") && !tempLink.startsWith("https://")) {
      toast.error("Por favor, insira um link válido iniciando com http:// ou https://");
      return;
    }

    localStorage.setItem("danielle_nani_checkout_link", tempLink);
    setCheckoutLink(tempLink);
    if (onLinkChange) {
      onLinkChange(tempLink);
    }
    setIsOpen(false);
    toast.success("Link de checkout atualizado com sucesso!");
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(checkoutLink);
    setIsCopied(true);
    toast.success("Link copiado para a área de transferência!");
    setTimeout(() => setIsCopied(false), 2000);
  };

  const resetToDefault = () => {
    if (confirm("Deseja realmente redefinir para o link de checkout padrão?")) {
      setTempLink(defaultLink);
      localStorage.setItem("danielle_nani_checkout_link", defaultLink);
      setCheckoutLink(defaultLink);
      if (onLinkChange) {
        onLinkChange(defaultLink);
      }
      toast.info("Link redefinido para o padrão.");
    }
  };

  return (
    <>
      {/* Botão Flutuante de Configuração - Apenas visível para o dono do site (simulado ou visível de forma sutil) */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setIsOpen(true)}
          className="bg-primary hover:bg-primary/90 text-white rounded-full w-12 h-12 flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-200 glow-purple"
          title="Configurar Link de Checkout"
        >
          <Settings className="w-6 h-6 animate-spin-slow" />
        </Button>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="glass-card text-foreground border-border max-w-md mx-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-white flex items-center gap-2">
              <Settings className="w-6 h-6 text-primary" />
              Painel de Checkout
            </DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Configure aqui o link do seu checkout de pagamento (Kiwify, Lastlink, Hotmart, PerfectPay, etc.) para onde os botões do site irão direcionar os clientes.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleSave} className="space-y-6 mt-4">
            <div className="space-y-2">
              <Label htmlFor="checkout-url" className="text-sm font-semibold text-white">
                URL do Checkout de Pagamento
              </Label>
              <div className="relative">
                <Input
                  id="checkout-url"
                  type="text"
                  value={tempLink}
                  onChange={(e) => setTempLink(e.target.value)}
                  placeholder="https://suaplataforma.com/checkout/..."
                  className="bg-background/80 border-border text-white pr-10 focus:border-primary focus:ring-1 focus:ring-primary"
                  required
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Insira o link completo da sua página de pagamento.
              </p>
            </div>

            {/* Informações Atuais */}
            <div className="bg-background/40 border border-border/50 rounded-lg p-3 space-y-2">
              <span className="text-xs font-bold text-primary uppercase tracking-wider">Configuração Ativa:</span>
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs truncate text-muted-foreground max-w-[280px]">
                  {checkoutLink}
                </span>
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="p-1 hover:bg-secondary rounded text-muted-foreground hover:text-white transition-colors"
                    title="Copiar Link"
                  >
                    {isCopied ? <Check className="w-4 h-4 text-accent" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <a
                    href={checkoutLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1 hover:bg-secondary rounded text-muted-foreground hover:text-white transition-colors"
                    title="Testar Link"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>

            {/* Aviso Importante */}
            <div className="flex gap-3 bg-primary/10 border border-primary/20 rounded-lg p-3 text-xs text-primary-foreground/90">
              <ShieldAlert className="w-5 h-5 text-primary shrink-0" />
              <div>
                <p className="font-semibold text-white">Aviso de Armazenamento</p>
                <p className="text-muted-foreground mt-0.5">
                  Esta configuração é salva no navegador local. Ao implantar o site, você poderá definir o link padrão diretamente no código ou usar este painel.
                </p>
              </div>
            </div>

            {/* Ações */}
            <div className="flex gap-3 justify-end">
              <Button
                type="button"
                variant="ghost"
                onClick={resetToDefault}
                className="text-muted-foreground hover:text-white hover:bg-secondary/50"
              >
                Padrão
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setTempLink(checkoutLink);
                  setIsOpen(false);
                }}
                className="border-border text-white hover:bg-secondary/50"
              >
                Cancelar
              </Button>
              <Button
                type="submit"
                className="bg-primary hover:bg-primary/90 text-white font-semibold"
              >
                Salvar Link
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
