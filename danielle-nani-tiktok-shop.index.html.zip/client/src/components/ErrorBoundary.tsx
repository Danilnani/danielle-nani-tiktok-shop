import React, { Component, ErrorInfo, ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { AlertTriangle, RefreshCw } from "lucide-react";

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export default class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("Uncaught error in ErrorBoundary:", error, errorInfo);
  }

  private handleReload = () => {
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#120e16] text-white flex flex-col items-center justify-center p-6 text-center">
          <div className="max-w-md w-full glass-card border border-red-500/20 rounded-3xl p-8 space-y-6 glow-purple">
            <div className="w-16 h-16 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-500 mx-auto">
              <AlertTriangle className="w-8 h-8" />
            </div>
            
            <div className="space-y-2">
              <h1 className="text-2xl font-bold">Ocorreu um erro inesperado</h1>
              <p className="text-sm text-muted-foreground">
                Não se preocupe, isso não afetará suas configurações. Tente recarregar a página para restaurar o funcionamento.
              </p>
            </div>

            {this.state.error && (
              <pre className="bg-background/80 border border-border text-left p-4 rounded-xl text-xs overflow-auto max-h-32 font-mono text-red-400">
                {this.state.error.toString()}
              </pre>
            )}

            <Button
              onClick={this.handleReload}
              className="w-full bg-primary hover:bg-primary/90 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Recarregar Página
            </Button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
