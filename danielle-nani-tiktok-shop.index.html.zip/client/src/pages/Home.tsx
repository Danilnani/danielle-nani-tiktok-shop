import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { 
  TrendingUp, 
  CheckCircle, 
  AlertTriangle, 
  PlayCircle, 
  Sparkles, 
  Gift, 
  ShieldCheck, 
  ArrowRight, 
  Smartphone, 
  DollarSign, 
  Clock, 
  Zap, 
  Check,
  Star,
  ChevronDown
} from "lucide-react";
import CheckoutConfig from "@/components/CheckoutConfig";

export default function Home() {
  // Estado para armazenar o link de checkout dinâmico
  const [checkoutLink, setCheckoutLink] = useState("https://lastlink.com/p/C1B37CAF5/checkout-payment/");
  const [timeLeft, setTimeLeft] = useState({ hours: 2, minutes: 14, seconds: 35 });
  const videoRef = React.useRef<HTMLVideoElement>(null);

  // Forçar o autoplay do vídeo programaticamente para burlar bloqueios de navegadores móveis
  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = true;
      videoRef.current.play().catch(error => {
        console.log("Autoplay bloqueado pelo navegador, tentando novamente...", error);
        // Tentar tocar novamente após interação ou pequeno delay
        const retryPlay = () => {
          if (videoRef.current) {
            videoRef.current.play().catch(e => console.log("Segunda tentativa de autoplay falhou:", e));
          }
          document.removeEventListener("click", retryPlay);
          document.removeEventListener("touchstart", retryPlay);
        };
        document.addEventListener("click", retryPlay);
        document.addEventListener("touchstart", retryPlay);
      });
    }
  }, []);

  // Sincronizar o link do CheckoutConfig com os botões da página
  const handleCheckoutLinkChange = (newLink: string) => {
    setCheckoutLink(newLink);
  };

  // Efeito do cronômetro de urgência (simulado)
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          // Reinicia para manter a urgência ativa
          return { hours: 2, minutes: 14, seconds: 35 };
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Formatar números do cronômetro com zero à esquerda
  const formatTime = (num: number) => num.toString().padStart(2, '0');

  // Dia da semana dinâmico em português
  const getBrazilianDayOfWeek = () => {
    const days = ["DOMINGO", "SEGUNDA-FEIRA", "TERÇA-FEIRA", "QUARTA-FEIRA", "QUINTA-FEIRA", "SEXTA-FEIRA", "SÁBADO"];
    return days[new Date().getDay()];
  };

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      
      {/* 1. Faixa Superior de Desconto e Urgência */}
      <div className="bg-primary text-white text-center py-2 px-4 text-xs md:text-sm font-semibold tracking-wider glow-purple relative z-10">
        Somente hoje, <span className="underline font-bold text-accent glow-text-green">{getBrazilianDayOfWeek()}</span>, você terá um desconto especial de 67%
      </div>

      {/* 2. Hero Section */}
      <header className="relative pt-12 pb-20 md:py-24 overflow-hidden">
        {/* Elementos de fundo abstratos */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-primary/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute top-10 left-10 w-24 h-24 bg-primary/20 rounded-full blur-3xl pointer-events-none" />
        
        <div className="container max-w-6xl relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Conteúdo Esquerdo */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <Badge className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 text-xs uppercase tracking-widest font-bold">
                🔥 A Maior Oportunidade de 2026
              </Badge>
              
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold leading-tight text-white">
                Enquanto você enrola, vários já estão <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent glow-text-purple">lucrando no TikTok Shop</span>
              </h1>
              
              <p className="text-base md:text-lg text-muted-foreground max-w-xl">
                O TikTok Shop é a <strong className="text-white">mina de ouro para ganhar dinheiro online</strong> em 2026. Existe uma estratégia escondida que bota dinheiro no bolso de pessoas comuns todos os dias — entre R$55 e R$470, sem anúncios, sem seguidores e sem aparecer.
              </p>

              {/* Lista de Benefícios Rápidos */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-accent/20 border border-accent/40 flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 text-accent" />
                  </div>
                  <span className="text-sm md:text-base text-white/90 font-medium">Apenas 1 hora por dia dedicada</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-accent/20 border border-accent/40 flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 text-accent" />
                  </div>
                  <span className="text-sm md:text-base text-white/90 font-medium">Do absoluto zero à primeira venda rápida</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-accent/20 border border-accent/40 flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 text-accent" />
                  </div>
                  <span className="text-sm md:text-base text-white/90 font-medium">Desconto de 67% ativo somente hoje</span>
                </div>
              </div>

              {/* Bloco de Preço e CTA */}
              <div className="pt-4 space-y-4">
                <div className="flex items-baseline gap-3">
                  <span className="text-muted-foreground line-through text-sm md:text-base">De R$497,00</span>
                  <span className="text-xs px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/30 font-bold">ECONOMIZE R$487,10</span>
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground text-sm font-semibold">Por apenas</span>
                  <span className="text-4xl md:text-5xl font-extrabold text-accent glow-text-green">R$ 9,90</span>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 items-stretch sm:items-center">
                  <a href={checkoutLink} className="grow sm:grow-0">
                    <Button className="w-full sm:w-auto bg-accent hover:bg-accent/90 text-background font-bold text-base md:text-lg px-8 py-6 rounded-xl transition-all duration-300 hover:scale-105 active:scale-95 glow-green flex items-center justify-center gap-2">
                      Começar Hoje
                      <ArrowRight className="w-5 h-5" />
                    </Button>
                  </a>
                  
                  {/* Cronômetro Compacto */}
                  <div className="flex items-center justify-center gap-2 bg-card/60 border border-border/60 rounded-xl px-4 py-2">
                    <Clock className="w-4 h-4 text-primary" />
                    <span className="text-xs text-muted-foreground">Expira em:</span>
                    <span className="text-sm font-bold text-white font-mono">
                      {formatTime(timeLeft.hours)}:{formatTime(timeLeft.minutes)}:{formatTime(timeLeft.seconds)}
                    </span>
                  </div>
                </div>
                
                <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">
                  ⚠️ GARANTA ANTES DO REAJUSTE IMINENTE DE PREÇO!
                </p>
              </div>
            </div>

            {/* Vídeo Demonstrativo Direito (Mais compacto e sem cortes) */}
            <div className="lg:col-span-5 relative flex justify-center">
              <div className="absolute inset-0 bg-primary/20 rounded-full blur-[80px] pointer-events-none" />
              <div className="relative border border-primary/20 rounded-3xl overflow-hidden shadow-2xl shadow-primary/10 bg-black/40 max-w-[320px] w-full">
                {/* Detalhe estético imitando a câmera/notch de um celular */}
                <div className="absolute top-2 left-1/2 -translate-x-1/2 w-24 h-4 bg-black rounded-full z-20 opacity-80 flex items-center justify-center">
                  <div className="w-2 h-2 rounded-full bg-zinc-800" />
                </div>
                
                <video 
                  ref={videoRef}
                  src="/manus-storage/AQMyO89tdINyCx0G1I8kc9Czeq67lq8FonQGSAtoOvrXLV7cAW1v5xe2huEAX9Ze8ewKYzAZoeBp-gep5bcP2NhvHn64IYT2IZ_gs1iTADZqBw_ce0f236f.mp4" 
                  controls
                  autoPlay
                  muted
                  loop
                  playsInline
                  className="w-full rounded-3xl aspect-[9/16] object-contain bg-black"
                />
              </div>
            </div>

          </div>
        </div>
      </header>

      {/* 3. Faixa de Urgência Infinita (Marquee) */}
      <div className="bg-secondary/40 border-y border-border py-3 overflow-hidden select-none">
        <div className="animate-marquee whitespace-nowrap flex gap-8">
          {Array(10).fill(null).map((_, i) => (
            <span key={i} className="text-xs md:text-sm font-bold tracking-widest text-primary flex items-center gap-2 uppercase">
              <AlertTriangle className="w-4 h-4 text-accent shrink-0" />
              Oferta disponível somente hoje
              <span className="text-accent">•</span>
              67% de desconto liberado
              <span className="text-accent">•</span>
              Vagas limitadas
            </span>
          ))}
        </div>
      </div>

      {/* 4. Seção Depoimento de Destaque */}
      <section className="py-16 md:py-24 relative">
        <div className="container max-w-4xl text-center space-y-8">
          <div className="inline-flex p-3 rounded-full bg-primary/10 border border-primary/20 text-primary">
            <Sparkles className="w-6 h-6" />
          </div>
          
          <h2 className="text-2xl md:text-4xl font-bold text-white max-w-2xl mx-auto leading-tight">
            Você está a um passo de aprender a estratégia que vai transformar seu celular em uma máquina de vendas automática.
          </h2>
          
          <div className="glass-card rounded-2xl p-6 md:p-10 border border-primary/20 relative">
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary px-4 py-1 rounded-full text-xs font-bold uppercase text-white tracking-widest">
              Depoimento de Aluna
            </div>
            
            <p className="text-lg md:text-xl text-white italic font-medium leading-relaxed">
              "Essa estratégia me salvou. Eu nunca tinha vendido nada online, e hoje eu faço entre R$ 50 a R$ 240 por dia sem precisar mostrar meu rosto ou criar estoque."
            </p>
            
            <div className="mt-6 flex items-center justify-center gap-3">
              <div className="flex text-accent">
                {Array(5).fill(null).map((_, i) => <Star key={i} className="w-4 h-4 fill-accent" />)}
              </div>
              <span className="text-sm font-semibold text-muted-foreground">— Amanda S., Aluna do Método Express</span>
            </div>
          </div>
          
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/50 border border-border text-xs font-semibold text-muted-foreground">
            <AlertTriangle className="w-4 h-4 text-primary" />
            Isso é possível apenas utilizando a estratégia Express.
          </div>
        </div>
      </section>

      {/* 5. Seção de Dor e Problema */}
      <section className="py-16 md:py-24 bg-card/40 border-y border-border relative">
        <div className="container max-w-5xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Texto Esquerdo */}
            <div className="lg:col-span-7 space-y-6">
              <Badge className="bg-red-500/10 text-red-400 border border-red-500/20 px-3 py-1 text-xs uppercase tracking-wider font-bold">
                ⚠️ Chega de perder tempo
              </Badge>
              
              <h2 className="text-2xl md:text-4xl font-bold text-white leading-tight">
                Se você responder <span className="text-primary">SIM</span> para alguma dessas perguntas, este conteúdo é para você:
              </h2>
              
              <div className="space-y-4 pt-2">
                {[
                  "Você já tentou vender online e só tomou prejuízo ou frustração?",
                  "Cansou de seguir tutoriais no YouTube que parecem fáceis mas nunca funcionam?",
                  "Já perdeu dinheiro com anúncios pagos que não deram retorno algum?",
                  "Sente que precisa de dinheiro extra rápido, mas não sabe por onde começar?"
                ].map((pergunta, index) => (
                  <div key={index} className="flex gap-3 items-start bg-background/50 border border-border/40 p-4 rounded-xl hover:border-primary/30 transition-colors">
                    <div className="w-6 h-6 rounded-full bg-red-500/10 border border-red-500/30 flex items-center justify-center shrink-0 mt-0.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                    </div>
                    <p className="text-sm md:text-base text-white/90 font-medium">{pergunta}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Ilustração Direita */}
            <div className="lg:col-span-5">
              <div className="relative border border-primary/10 rounded-2xl overflow-hidden shadow-xl">
                <img 
                  src="https://d2xsxph8kpxj0f.cloudfront.net/310519663721201731/PURXLqKN9KSgQVzkqCQAy7/tiktok-shop-illustration-ShPuoLBHcVH9JSJ7J2hXJb.webp" 
                  alt="TikTok Shop Ilustração" 
                  className="w-full object-cover rounded-2xl"
                />
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Seção de Depoimentos de Alunos (Nova) */}
      <section className="py-16 md:py-24 relative overflow-hidden">
        <div className="absolute top-1/3 right-10 w-72 h-72 bg-primary/5 rounded-full blur-[100px] pointer-events-none" />
        <div className="container max-w-5xl space-y-12 relative z-10">
          <div className="text-center space-y-4">
            <Badge className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 text-xs uppercase tracking-widest font-bold">
              ⭐ RESULTADOS REAIS
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold text-white">
              Quem aplica o Método Express, <span className="text-primary">vende todos os dias</span>
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Veja o que nossos alunos estão falando sobre o método e os resultados que estão alcançando em tempo recorde.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                name: "Lucas Menezes",
                age: "24 anos",
                tag: "R$ 4.210,00 no primeiro mês",
                text: "Eu estava cético no começo porque já tinha tentado de tudo no marketing digital. Mas o método da Dani é diferente. É direto ao ponto. Em menos de 48 horas após ativar minha loja, fiz minha primeira venda. Hoje é meu sustento principal.",
                stars: 5,
                city: "São Paulo - SP"
              },
              {
                name: "Mariana Costa",
                age: "31 anos",
                tag: "Mãe e empreendedora digital",
                text: "Como tenho filho pequeno, meu tempo é curtíssimo. Consigo aplicar a estratégia da Dani em apenas 1 hora por dia enquanto ele dorme. As ferramentas de IA facilitam demais a criação dos vídeos. Recomendo muito para quem tem pouco tempo!",
                stars: 5,
                city: "Belo Horizonte - MG"
              },
              {
                name: "Thiago Rocha",
                age: "28 anos",
                tag: "Fez R$ 180 no primeiro dia",
                text: "O suporte é maravilhoso e o método realmente funciona sem precisar gastar com anúncios. Segui o checklist passo a passo e o algoritmo do TikTok entregou meu primeiro vídeo muito rápido. Melhor investimento de R$ 9,90 que já fiz na vida.",
                stars: 5,
                city: "Curitiba - PR"
              }
            ].map((depoimento, index) => (
              <div key={index} className="glass-card border border-primary/10 rounded-2xl p-6 flex flex-col justify-between space-y-6 hover:border-primary/30 transition-all duration-300 hover:scale-[1.02]">
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="space-y-1">
                      <h4 className="font-bold text-white text-lg">{depoimento.name}</h4>
                      <p className="text-xs text-muted-foreground">{depoimento.age} • {depoimento.city}</p>
                    </div>
                    <div className="flex text-accent">
                      {Array(depoimento.stars).fill(null).map((_, i) => (
                        <Star key={i} className="w-3.5 h-3.5 fill-accent text-accent" />
                      ))}
                    </div>
                  </div>
                  <Badge className="bg-primary/10 text-primary border border-primary/20 text-xs font-semibold py-0.5">
                    {depoimento.tag}
                  </Badge>
                  <p className="text-sm text-muted-foreground leading-relaxed italic">
                    "{depoimento.text}"
                  </p>
                </div>
                <div className="pt-4 border-t border-border/40 flex items-center gap-2 text-xs text-emerald-400 font-semibold">
                  <CheckCircle className="w-4 h-4" />
                  Aluno Verificado
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. O que você vai aprender */}
      <section className="py-16 md:py-24 relative">
        <div className="container max-w-5xl text-center space-y-12">
          <div className="space-y-4">
            <Badge className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 text-xs uppercase tracking-widest font-bold">
              📚 O Conteúdo do Treinamento
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold text-white">
              Veja exatamente o que você vai aprender:
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Um passo a passo extremamente direto ao ponto, sem enrolação teórica. Você vai direto para a prática lucrativa.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
            {[
              {
                title: "Ativação Express do TikTok Shop",
                desc: "Como ativar a nova ferramenta do TikTok Shop em tempo recorde para começar a faturar imediatamente."
              },
              {
                title: "Vídeos Lucrativos sem Aparecer",
                desc: "O método exato para criar e publicar vídeos magnéticos de produtos que geram vendas automáticas sem mostrar o rosto."
              },
              {
                title: "Comissões Premium de 10% a 30%",
                desc: "Como se posicionar para garantir as maiores taxas de comissão do mercado, maximizando seu lucro por venda realizada."
              },
              {
                title: "Inteligência Artificial de Vendas",
                desc: "Como utilizar ferramentas de IA secretas para automatizar a criação de conteúdo e multiplicar seus resultados diários."
              }
            ].map((item, index) => (
              <div key={index} className="glass-card border border-primary/15 rounded-2xl p-6 hover:border-primary/40 transition-all duration-300 hover:scale-[1.01] flex gap-4">
                <div className="w-10 h-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0 text-primary">
                  <CheckCircle className="w-6 h-6" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-lg font-bold text-white">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-4">
            <a href={checkoutLink}>
              <Button className="bg-accent hover:bg-accent/90 text-background font-bold text-base md:text-lg px-8 py-6 rounded-xl transition-all duration-300 hover:scale-105 active:scale-95 glow-green">
                Começar Hoje
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* 7. Entregáveis detalhados (Módulos / O que você vai receber) */}
      <section className="py-16 md:py-24 bg-card/30 border-t border-border relative">
        <div className="container max-w-5xl space-y-12">
          <div className="text-center space-y-4">
            <Badge className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 text-xs uppercase tracking-widest font-bold">
              📦 O que você vai receber
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold text-white">
              Tudo que está incluso no Método Express:
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Ao garantir seu acesso hoje por apenas R$ 7, você destrava imediatamente o pacote completo de ferramentas e estratégias.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              {
                badge: "Método Express",
                title: "Passo a Passo para ativar o TikTok Shop rápido",
                desc: "Você vai aprender o caminho exato e mastigado para ativar o novo TikTok Shop em tempo recorde e habilitar sua conta para faturar."
              },
              {
                badge: "Método Express",
                title: "IA Secreta para Vídeos Automáticos em Minutos",
                desc: "Vou liberar o acesso à inteligência artificial secreta que transforma ideias em vídeos prontos para vender de forma 100% automática."
              },
              {
                badge: "Método Express",
                title: "Checklist de Ativação Sem Erros",
                desc: "Um checklist prático de 'copiar e colar'. Siga cada etapa de forma sequencial para configurar sua máquina de vendas sem margem de erro."
              },
              {
                badge: "Método Express",
                title: "Produto com Comissão Premium Exclusivo",
                desc: "Acesso direto a um produto de altíssima conversão com comissões de 20% a 30% por venda, muito acima do mercado tradicional."
              }
            ].map((item, index) => (
              <div key={index} className="bg-background/60 border border-border/80 rounded-2xl p-6 hover:border-primary/30 transition-all duration-300 flex flex-col justify-between space-y-4 relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-full blur-xl group-hover:bg-primary/10 transition-colors" />
                
                <div className="space-y-3">
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-primary bg-primary/10 px-2.5 py-1 rounded-full border border-primary/20">
                    {item.badge}
                  </span>
                  <h3 className="text-lg md:text-xl font-bold text-white pt-1">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. Seção "Quem é Danielle Nani" (Personalizada) */}
      <section className="py-16 md:py-24 bg-secondary/10 border-y border-border relative">
        <div className="container max-w-5xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Foto de Perfil Esquerda */}
            <div className="lg:col-span-5 relative">
              <div className="absolute inset-0 bg-primary/10 rounded-full blur-[60px] pointer-events-none" />
              <div className="relative border border-primary/20 rounded-2xl overflow-hidden shadow-2xl">
                <img 
                  src="/manus-storage/ChatGPTImage11demai.de2026,17_42_11_f5214674.png" 
                  alt="Danielle Nani" 
                  className="w-full object-cover rounded-2xl"
                />
              </div>
            </div>

            {/* História de Danielle Nani Direita */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <Badge className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 text-xs uppercase tracking-widest font-bold">
                👤 Quem é Danielle Nani
              </Badge>
              
              <h2 className="text-3xl md:text-4xl font-bold text-white">
                Muito prazer, eu sou a <span className="text-primary">Dani</span>
              </h2>
              
              <div className="space-y-4 text-muted-foreground text-sm md:text-base leading-relaxed">
                <p>
                  Tenho <strong className="text-white">32 anos</strong> e trabalho há <strong className="text-white">6 anos no mercado digital</strong> como correspondente bancária e com infoprodutos. Ao longo dessa jornada, testei diversos caminhos, mas foi no <strong className="text-white">TikTok Shop</strong> que encontrei a forma mais rápida e acessível de lucrar através da internet hoje em dia.
                </p>
                <p>
                  A grande vantagem desse modelo é a simplicidade e o alcance orgânico absurdo que a plataforma entrega. Não é necessário gastar fortunas com anúncios ou se expor gravando vídeos se você não quiser.
                </p>
                <p className="text-white font-semibold">
                  ⚡ Qualquer pessoa, mesmo começando do absoluto zero, consegue aplicar esse método simples e vender todos os dias de forma consistente.
                </p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 9. Oferta Final / Caixa de Fechamento */}
      <section className="py-16 md:py-24 relative">
        <div className="container max-w-4xl text-center">
          <div className="glass-card border border-primary/30 rounded-3xl p-8 md:p-12 space-y-8 relative overflow-hidden glow-purple">
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-2xl pointer-events-none" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-accent/5 rounded-full blur-2xl pointer-events-none" />
            
            <div className="space-y-3">
              <Badge className="bg-accent/20 text-accent border border-accent/30 px-3 py-1 text-xs uppercase tracking-widest font-bold">
                🎁 OFERTA ESPECIAL DE HOJE
              </Badge>
              <h2 className="text-2xl md:text-4xl font-bold text-white">
                Método Express + Acesso a Comissões Diferenciadas
              </h2>
              <p className="text-muted-foreground max-w-lg mx-auto text-sm md:text-base">
                Garanta sua vaga agora e destrave imediatamente o método completo para ativar e faturar no TikTok Shop.
              </p>
            </div>

            {/* Checklist Resumo */}
            <div className="max-w-md mx-auto bg-background/50 border border-border/60 rounded-2xl p-5 text-left space-y-3">
              {[
                "Como ativar o novo TikTok Shop e começar a faturar",
                "Como criar vídeos que geram lucro sem precisar aparecer",
                "Como ter acesso às maiores comissões (10% a 20%)",
                "Como usar IA secreta para criar vídeos automáticos",
                "Bônus: Produto com Comissão Premium de 20% a 30%"
              ].map((item, index) => (
                <div key={index} className="flex gap-2.5 items-start text-xs md:text-sm text-white/90">
                  <Check className="w-4 h-4 text-accent shrink-0 mt-0.5" />
                  <span>{item}</span>
                </div>
              ))}
            </div>

            {/* Preço e Botão */}
            <div className="space-y-4 pt-2">
              <div className="text-muted-foreground text-sm line-through">
                VALOR TOTAL REAL: R$ 497,00
              </div>
              
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Tudo isso por apenas...</p>
                <p className="text-5xl md:text-6xl font-extrabold text-accent glow-text-green">R$ 9,90</p>
                <p className="text-xs text-muted-foreground font-semibold uppercase tracking-wider">Pagamento único • Sem mensalidades</p>
              </div>

              <div className="pt-2">
                <a href={checkoutLink}>
                  <Button className="w-full sm:w-auto bg-accent hover:bg-accent/90 text-background font-bold text-lg md:text-xl px-12 py-7 rounded-xl transition-all duration-300 hover:scale-105 active:scale-95 glow-green flex items-center justify-center gap-2 mx-auto">
                    Começar Hoje
                    <ArrowRight className="w-5 h-5" />
                  </Button>
                </a>
              </div>
            </div>

            {/* Garantia */}
            <div className="pt-6 border-t border-border/50 flex flex-col sm:flex-row items-center justify-center gap-4 text-left max-w-md mx-auto">
              <div className="w-12 h-12 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center text-primary shrink-0">
                <ShieldCheck className="w-7 h-7" />
              </div>
              <div className="space-y-1 text-center sm:text-left">
                <h4 className="text-sm font-bold text-white">Garantia Incondicional de 7 Dias</h4>
                <p className="text-xs text-muted-foreground">
                  Você entra, assiste e aplica. Se por qualquer motivo não gostar do conteúdo, basta solicitar o reembolso integral. Risco zero para você.
                </p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 10. Seção FAQ (Perguntas Frequentes) */}
      <section className="py-16 md:py-24 bg-card/20 border-t border-border relative">
        <div className="container max-w-4xl space-y-12">
          <div className="text-center space-y-4">
            <Badge className="bg-primary/20 text-primary border border-primary/30 px-3 py-1 text-xs uppercase tracking-widest font-bold">
              💬 Tire suas dúvidas
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold text-white">
              Ficou com alguma dúvida?
            </h2>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Veja as respostas para as perguntas mais comuns de novos alunos sobre o funcionamento do Método Express.
            </p>
          </div>

          <Accordion type="single" collapsible className="space-y-4 w-full text-left">
            {[
              {
                q: "Por que esse conteúdo custa tão barato se vale muito mais?",
                a: "Nosso objetivo é tornar o conhecimento acessível para qualquer pessoa começar do zero no digital. O preço de R$ 7 é promocional para facilitar sua entrada hoje, mas o valor real de mercado desse método é de R$ 497 e o preço subirá em breve."
              },
              {
                q: "Preciso mostrar o rosto nos vídeos para vender?",
                a: "Não! O Método Express é focado em estratégias 'sem aparecer' (canais dark/automatizados). Ensinamos você a usar inteligência artificial para criar vídeos de alta conversão sem precisar expor sua imagem."
              },
              {
                q: "Quais formas de pagamento posso usar para entrar hoje?",
                a: "Você pode pagar via Pix (com liberação imediata do acesso) ou cartão de crédito em ambiente 100% seguro."
              },
              {
                q: "Tenho que gastar dinheiro com anúncios para funcionar?",
                a: "Não é necessário gastar um centavo com anúncios pagos. O método utiliza o algoritmo de entrega orgânica do TikTok, que é o mais potente do mundo atualmente, gerando visualizações e vendas sem investimento."
              },
              {
                q: "O curso tem algum grupo de suporte?",
                a: "Sim, disponibilizamos suporte direto na plataforma de membros para responder a todas as suas dúvidas durante a aplicação prática do método."
              },
              {
                q: "Sou iniciante total, ainda dá certo para mim?",
                a: "Com certeza. O treinamento foi estruturado em formato de passo a passo detalhado, pegando você pela mão desde a criação da conta até a realização das primeiras vendas diárias."
              },
              {
                q: "Quanto tempo tenho acesso ao treinamento?",
                a: "Seu acesso é vitalício. Você pode assistir às aulas no seu ritmo, quando e onde quiser, além de receber todas as atualizações futuras sem custo adicional."
              },
              {
                q: "Tenho pouco tempo livre... esse método ainda serve para mim?",
                a: "Sim! O método foi desenhado para pessoas ocupadas. Com apenas 1 hora por dia dedicada e focada, você consegue estruturar a estratégia e colocar os vídeos automáticos para rodar."
              }
            ].map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`faq-${index}`}
                className="glass-card border border-border/80 rounded-2xl px-6 py-1 hover:border-primary/20 transition-colors"
              >
                <AccordionTrigger className="text-base font-bold text-white hover:text-primary hover:no-underline py-4">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-sm leading-relaxed pb-4 border-t border-border/30 pt-3">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="pt-4 text-center">
            <a href={checkoutLink}>
              <Button className="bg-accent hover:bg-accent/90 text-background font-bold text-base md:text-lg px-8 py-6 rounded-xl transition-all duration-300 hover:scale-105 active:scale-95 glow-green">
                Começar Hoje
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* 11. Rodapé (Footer) */}
      <footer className="py-12 bg-background border-t border-border/60 relative z-10">
        <div className="container max-w-5xl text-center space-y-6">
          <p className="text-sm font-bold text-white">
            Danielle Nani • TikTok Shop Express
          </p>
          <p className="text-xs text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Este site não é afiliado ao TikTok ou a qualquer entidade do TikTok. Após a compra, o acesso ao produto digital será enviado para o seu e-mail cadastrado. Todos os direitos reservados. © {new Date().getFullYear()}
          </p>
        </div>
      </footer>

      {/* Componente de Configuração do Checkout (Painel Flutuante) */}
      <CheckoutConfig onLinkChange={handleCheckoutLinkChange} defaultLink="https://lastlink.com/p/C1B37CAF5/checkout-payment/" />

    </div>
  );
}
