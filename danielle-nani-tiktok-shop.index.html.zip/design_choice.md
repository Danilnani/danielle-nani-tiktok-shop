# Escolha do Design: Neon Lilac Cyberpunk (Abordagem 1)

Decidimos seguir integralmente com a **Abordagem 1: Neon Lilac Cyberpunk**. Esta escolha se baseia no fato de que o produto vendido é focado em estratégias de ganho rápido e automação no **TikTok Shop**, uma plataforma extremamente dinâmica, jovem e tecnológica. O estilo cyberpunk moderno transmite a ideia de uma "estratégia escondida", "mina de ouro" e "máquina de vendas automática" de forma visualmente coerente e muito atraente.

## Diretrizes de Estilo a Serem Aplicadas:

1. **Paleta de Cores (OKLCH)**:
   - Fundo (Background): `oklch(0.15 0.02 290)` (Cinza-escuro quase preto, misterioso e imersivo)
   - Texto (Foreground): `oklch(0.95 0.01 290)` (Branco acinzentado, excelente legibilidade)
   - Primária (Lilás Neon / Ametista): `oklch(0.65 0.25 300)` (Destaque tecnológico, marca)
   - Secundária (Roxo Escuro): `oklch(0.25 0.05 295)` (Para cards e elementos de suporte)
   - Destaque de Conversão (Verde-Limão Neon): `oklch(0.85 0.20 120)` (Exclusivo para CTAs, botões de checkout e badges de urgência)
   - Bordas: `oklch(0.30 0.04 295)` (Sutil e elegante)

2. **Tipografia**:
   - Títulos: "Space Grotesk" (Display, geométrica, futurista, imponente)
   - Corpo: "Plus Jakarta Sans" (Moderna, limpa, legível em telas digitais)

3. **Elementos Visuais Assinatura**:
   - Cards com efeito de vidro jateado (Glassmorphism) usando fundos semi-transparentes e bordas iluminadas com gradientes sutis de lilás para roxo.
   - Divisórias finas e brilhantes simulando feixes de neon.
   - Efeitos de "glow" (brilho externo) suave em botões e badges de urgência.
   - Marquee horizontal infinito para as faixas de urgência "OFERTA DISPONÍVEL SOMENTE HOJE".

4. **Interações e Animações**:
   - Botões de compra com pulsação suave e efeito de hover com brilho expandido.
   - Transição ativa `:active` com escala sutil (`scale(0.97)`) para feedback tátil.
   - Revelação gradual de seções ao rolar a página (staggered delay).
   - Accordion de FAQ abrindo com transição suave.
