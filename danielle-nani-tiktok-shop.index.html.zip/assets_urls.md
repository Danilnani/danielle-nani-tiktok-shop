# URLs dos Ativos Visuais para o Desenvolvimento

As imagens foram geradas com sucesso e otimizadas em formato WebP comprimido para carregamento ultra-rápido. Devem ser utilizadas as seguintes URLs diretamente no código do frontend:

1. **Mockup Digital do Método Express (Hero/Seção de Oferta)**:
   - URL Comprimida (Recomendada): `https://d2xsxph8kpxj0f.cloudfront.net/310519663721201731/PURXLqKN9KSgQVzkqCQAy7/danielle-mockup-GVtnVJFEz6VRJJ6DoHRywx.webp`
   - URL Original: `https://d2xsxph8kpxj0f.cloudfront.net/310519663721201731/PURXLqKN9KSgQVzkqCQAy7/danielle-mockup-NgJzjMQBhxkcu3vvY82XcS.png`

2. **Foto de Perfil Profissional de Danielle Nani (Seção "Quem é Danielle Nani")**:
   - URL Comprimida (Recomendada): `https://d2xsxph8kpxj0f.cloudfront.net/310519663721201731/PURXLqKN9KSgQVzkqCQAy7/danielle-profile-dPSjP3pihPJEuXTfnqjpYf.webp`
   - URL Original: `https://d2xsxph8kpxj0f.cloudfront.net/310519663721201731/PURXLqKN9KSgQVzkqCQAy7/danielle-profile-Z7MegQtfMBw55HpzJcjwUn.png`

3. **Ilustração de Vendas Automáticas do TikTok Shop (Seção de Benefícios/Estratégia)**:
   - URL Comprimida (Recomendada): `https://d2xsxph8kpxj0f.cloudfront.net/310519663721201731/PURXLqKN9KSgQVzkqCQAy7/tiktok-shop-illustration-ShPuoLBHcVH9JSJ7J2hXJb.webp`
   - URL Original: `https://d2xsxph8kpxj0f.cloudfront.net/310519663721201731/PURXLqKN9KSgQVzkqCQAy7/tiktok-shop-illustration-gAcwMSZQcgy7qjovPMfcFB.png`
